# E-Commerce Backend Application

## Project Information

**Student Name:** Aditya Singh Dewangan  
**Registration Number:** 24BCE11204

---

## Project Overview

This project is a RESTful E-Commerce Backend Application developed using Spring Boot and MongoDB. It provides APIs for managing categories, products, customers, and orders.

The application follows a layered architecture using Spring Boot for backend development and MongoDB as the NoSQL database.

---

## Technology Stack

- Java 17+
- Spring Boot
- Spring Data MongoDB
- MongoDB
- Maven
- Lombok
- REST APIs

---

## Project Modules

### 1. Category Management
- Create Category
- View Categories

### 2. Product Management
- Create Product
- View Products

### 3. Customer Management
- Create Customer
- View Customers

### 4. Order Management
- Create Orders
- View Orders

---

## Project Structure

```text
ecommerce
│
├── controller
│   ├── CategoryController.java
│   ├── ProductController.java
│   ├── CustomerController.java
│   └── OrderController.java
│
├── model
│   ├── Category.java
│   ├── Product.java
│   ├── Address.java
│   ├── Customer.java
│   ├── Order.java
│   └── OrderItem.java
│
├── repository
│   ├── CategoryRepository.java
│   ├── ProductRepository.java
│   ├── CustomerRepository.java
│   └── OrderRepository.java
│
├── EcommerceApplication.java
│
└── resources
    └── application.properties
```

---

## Database Configuration

```properties
spring.application.name=ecommerce

spring.data.mongodb.uri=mongodb://localhost:27017/ecommerce
```

---

## API Endpoints

### Category APIs

| Method | Endpoint |
|----------|----------|
| POST | /categories |
| GET | /categories |

### Product APIs

| Method | Endpoint |
|----------|----------|
| POST | /products |
| GET | /products |

### Customer APIs

| Method | Endpoint |
|----------|----------|
| POST | /customers |
| GET | /customers |

### Order APIs

| Method | Endpoint |
|----------|----------|
| POST | /orders |
| GET | /orders |

---

## How to Run the Project

### Step 1: Start MongoDB

```bash
brew services start mongodb-community
```

### Step 2: Navigate to Project Folder

```bash
cd ecommerce
```

### Step 3: Build Project

```bash
mvn clean install
```

### Step 4: Run Spring Boot Application

```bash
mvn spring-boot:run
```

Application will start at:

```text
http://localhost:8080
```

---

## Sample API Testing

### Get Categories

```bash
curl http://localhost:8080/categories
```

### Get Products

```bash
curl http://localhost:8080/products
```

### Get Customers

```bash
curl http://localhost:8080/customers
```

### Get Orders

```bash
curl http://localhost:8080/orders
```

---

## Learning Outcomes

- Spring Boot Application Development
- REST API Development
- MongoDB Integration
- Maven Build Management
- CRUD Operations
- Repository Pattern
- JSON Request and Response Handling
- Backend Application Architecture

---

## Future Enhancements

- Service Layer Implementation
- Exception Handling
- Validation
- JWT Authentication
- Role-Based Authorization
- React Frontend Integration
- Docker Deployment
- Cloud Deployment

---

## Author

**Aditya Singh Dewangan**  
**Registration Number:** 24BCE11204

Bachelor of Technology (B.Tech)  
Computer Science and Engineering

---