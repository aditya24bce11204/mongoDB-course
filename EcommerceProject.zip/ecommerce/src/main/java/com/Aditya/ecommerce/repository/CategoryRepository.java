package com.Aditya.ecommerce.repository;

import com.Aditya.ecommerce.model.Category;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CategoryRepository
        extends MongoRepository<Category, String> {
}