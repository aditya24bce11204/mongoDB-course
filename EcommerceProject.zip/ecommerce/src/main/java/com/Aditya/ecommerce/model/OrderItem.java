package com.Aditya.ecommerce.model;

import lombok.Data;

@Data
public class OrderItem {
    private String productId;
    private int quantity;
    private double unitPrice;
}
